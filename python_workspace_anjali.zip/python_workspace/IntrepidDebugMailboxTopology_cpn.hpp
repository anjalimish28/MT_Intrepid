// ======================================================================
// Generated CAN Mailbox topology configuration
// Source model: intrepid.ucof
// Device: CCDPU
// Target implementation: va41620peb1 / ebi-ethernet board
// Mailbox config: CPN_CAN_Mailbox_Config
// Node address symbol: CAN_ADDR_CPN
// ======================================================================

static CandoSvc::CanMailbox::CDSP_DADR s_canFilterList[] = {
    CandoSvc::CAN_ADDR_CPN
};
static CandoSvc::CanMailbox::MailboxOutConfig s_canMbOut[] = {
    {0x0, CandoSvc::CAN_ADDR_CPN, CandoSvc::CAN_ADDR_RDC_2},
    {0x1, CandoSvc::CAN_ADDR_CPN, CandoSvc::CAN_ADDR_RDC_MC, true}
};
static CandoSvc::CanMailbox::CDSP_SADR s_canSenderFilterList[] = {
    CandoSvc::CAN_ADDR_RDC_2
};
