#ifndef RDC_CONFIG_HPP_
#define RDC_CONFIG_HPP_

#include <Fw/FPrimeBasicTypes.hpp>

namespace RdcConfig
{
constexpr U8 RD_FRQ_HZ = 1000;
constexpr U8 RG_DIV_1 = 1;
constexpr U8 RG_DIV_2 = 5;
constexpr U8 RG_DIV_3 = 10;
constexpr U8 PWM_RES = 16;
constexpr U8 IO_PIN_MBS_EN = 7;
constexpr U8 PWM_PIN_MBS = 3;
constexpr U8 IO_PIN_MBS_DIR = 6;
constexpr U8 IO_PIN_GIM_EN = 11;
constexpr U8 PWM_PIN_GIM = 9;
constexpr U8 IO_PIN_GIM_DIR = 8;
constexpr U8 IO_PIN_FLY_EN = 13;
constexpr U8 PWM_PIN_FLY = 10;
constexpr U8 IO_PIN_FLY_DIR = 12;

} // namespace RdcConfig

#endif /* RDC_CONFIG_HPP_ */
