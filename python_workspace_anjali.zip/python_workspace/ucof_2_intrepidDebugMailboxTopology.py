import sys
from pathlib import Path

from general_utils import init_log, print_with_time, find_by_attr, find_by_class_name, select_from_list  # type: ignore
from ucof_utils import import_ucof_platform_from_file  # type: ignore

sys.path.append(str(Path(__file__).parent / "PythonClasses"))


def get_target_implementation(ucof_platform, device_id):
    target_implementation = None
    impl_assignment = find_by_attr(
        ucof_platform,
        "sourceID",
        device_id,
        False,
        "DeviceToImplementationAssignment"
    )
    if impl_assignment:
        target_implementation = find_by_attr(
            ucof_platform,
            "id",
            impl_assignment.targetID,
            False
        )
    return target_implementation


def get_msg_box_extension(target_implementation):
    if not target_implementation:
        return None
    return getattr(target_implementation, "msgBoxExtension", None)


def get_ref_list(obj, ref_name):
    """
    Robustly read containment references from generated PythonClasses.

    Depending on generation style, the reference may appear as:
      - obj.incomingDestinationFilter
      - obj.incomingDestinationFilter_list
      - obj.senderSourceFilter
      - obj.senderSourceFilter_list
      - obj.outgoingMailboxSlot
      - obj.outgoingMailboxSlot_list
    """
    candidates = [ref_name, f"{ref_name}_list"]
    for candidate in candidates:
        if hasattr(obj, candidate):
            value = getattr(obj, candidate)
            if value is None:
                return []
            if isinstance(value, list):
                return value
            return [value]
    return []


def get_required_attr(obj, attr_name):
    value = getattr(obj, attr_name, None)
    if value is None or value == "":
        obj_name = getattr(obj, "name", obj.__class__.__name__)
        raise ValueError(
            f"Missing required attribute '{attr_name}' on '{obj_name}' "
            f"({obj.__class__.__name__})"
        )
    return value


def get_optional_attr(obj, attr_name, default_value):
    value = getattr(obj, attr_name, None)
    if value is None or value == "":
        return default_value
    return value


def to_bool(value):
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in ["true", "1", "yes"]


def cpp_address(address_symbol):
    address_symbol = str(address_symbol).strip()
    if address_symbol.startswith("CandoSvc::"):
        return address_symbol
    return f"CandoSvc::{address_symbol}"


def get_device_mailbox_configs(ucof_platform):
    """
    Find mailbox configurations through the explicit model relation:

      device -> DeviceToImplementationAssignment -> target implementation -> msgBoxExtension

    This keeps the topology generator aligned with the RDC template style.
    """
    mailbox_entries = []
    device_list = ucof_platform.devices.device_list

    for ucof_device in device_list:
        device_id = ucof_device.id
        print_with_time(
            f"Checking if device with id: {device_id} has mailbox topology data..."
        )
        target_implementation = get_target_implementation(ucof_platform, device_id)
        if target_implementation:
            target_class = target_implementation.__class__.__name__
            target_name = getattr(target_implementation, "name", "<unnamed>")
            print_with_time(
                f"... implementation found: {target_class} with name: {target_name}"
            )
            msg_box = get_msg_box_extension(target_implementation)
            if msg_box:
                print_with_time(
                    f"... mailbox confirmed: {getattr(msg_box, 'name', '<unnamed>')}"
                )
                mailbox_entries.append({
                    "device": ucof_device,
                    "target": target_implementation,
                    "msgBoxExtension": msg_box,
                })
            else:
                print_with_time("... implementation has no msgBoxExtension")
        else:
            print_with_time("... no DeviceToImplementationAssignment found")

    if not mailbox_entries:
        raise RuntimeError(
            "No msgBoxExtension found through DeviceToImplementationAssignment."
        )
    return mailbox_entries


def get_mailbox_entry_by_node(mailbox_entries, node_name):
    """
    Selects one mailbox node config.

    Supported values:
      CPN, RDC, RDC_2, CAN_ADDR_CPN, CAN_ADDR_RDC_2,
      RDC_CAN_Mailbox_Config, CPN_CAN_Mailbox_Config
    """
    aliases = {
        "CPN": "CAN_ADDR_CPN",
        "RDC": "CAN_ADDR_RDC_2",
        "RDC_2": "CAN_ADDR_RDC_2",
    }
    wanted_symbol = aliases.get(node_name, node_name)

    for entry in mailbox_entries:
        device = entry["device"]
        msg_box = entry["msgBoxExtension"]
        device_name = getattr(device, "name", "")
        msg_box_name = getattr(msg_box, "name", "")
        node_symbol = getattr(msg_box, "nodeAddressSymbol", "")
        if node_name == device_name:
            return entry
        if node_name == msg_box_name:
            return entry
        if wanted_symbol == node_symbol:
            return entry

    available = [
        f"{getattr(entry['device'], 'name', '<unnamed device>')} -> "
        f"{getattr(entry['msgBoxExtension'], 'name', '<unnamed mailbox>')} "
        f"({getattr(entry['msgBoxExtension'], 'nodeAddressSymbol', '<missing>')})"
        for entry in mailbox_entries
    ]
    raise RuntimeError(
        f"No mailbox entry found for node '{node_name}'. Available: {available}"
    )


def render_destination_filter_list(msg_box):
    filters = get_ref_list(msg_box, "incomingDestinationFilter")
    if not filters:
        raise RuntimeError(
            f"No incomingDestinationFilter entries found for "
            f"{getattr(msg_box, 'name', '<unnamed>')}"
        )
    lines = []
    lines.append("static CandoSvc::CanMailbox::CDSP_DADR s_canFilterList[] = {")
    for index, filter_entry in enumerate(filters):
        address_symbol = get_required_attr(filter_entry, "addressSymbol")
        comma = "," if index < len(filters) - 1 else ""
        lines.append(f"    {cpp_address(address_symbol)}{comma}")
    lines.append("};")
    lines.append("")
    return "\n".join(lines)


def render_sender_filter_list(msg_box):
    filters = get_ref_list(msg_box, "senderSourceFilter")
    if not filters:
        raise RuntimeError(
            f"No senderSourceFilter entries found for "
            f"{getattr(msg_box, 'name', '<unnamed>')}"
        )
    lines = []
    lines.append("static CandoSvc::CanMailbox::CDSP_SADR s_canSenderFilterList[] = {")
    for index, filter_entry in enumerate(filters):
        address_symbol = get_required_attr(filter_entry, "addressSymbol")
        comma = "," if index < len(filters) - 1 else ""
        lines.append(f"    {cpp_address(address_symbol)}{comma}")
    lines.append("};")
    lines.append("")
    return "\n".join(lines)


def render_outgoing_mailbox_slots(msg_box):
    slots = get_ref_list(msg_box, "outgoingMailboxSlot")
    if not slots:
        raise RuntimeError(
            f"No outgoingMailboxSlot entries found for "
            f"{getattr(msg_box, 'name', '<unnamed>')}"
        )
    lines = []
    lines.append("static CandoSvc::CanMailbox::MailboxOutConfig s_canMbOut[] = {")
    for index, slot in enumerate(slots):
        port_id = get_required_attr(slot, "portId")
        source_symbol = get_required_attr(slot, "sourceAddressSymbol")
        destination_symbol = get_required_attr(slot, "destinationAddressSymbol")
        multicast = to_bool(get_optional_attr(slot, "multicast", False))
        source_cpp = cpp_address(source_symbol)
        destination_cpp = cpp_address(destination_symbol)
        comma = "," if index < len(slots) - 1 else ""
        if multicast:
            lines.append(
                f"    {{{port_id}, {source_cpp}, {destination_cpp}, true}}{comma}"
            )
        else:
            lines.append(
                f"    {{{port_id}, {source_cpp}, {destination_cpp}}}{comma}"
            )
    lines.append("};")
    lines.append("")
    return "\n".join(lines)


def write_intrepid_debug_topology_into_file(mailbox_entry, output_path):
    device = mailbox_entry["device"]
    target = mailbox_entry["target"]
    msg_box = mailbox_entry["msgBoxExtension"]
    device_name = getattr(device, "name", "<unnamed>")
    target_name = getattr(target, "name", "<unnamed>")
    target_class = target.__class__.__name__
    msg_box_name = getattr(msg_box, "name", "<unnamed>")
    node_symbol = getattr(msg_box, "nodeAddressSymbol", "<missing>")

    main = f"""// ======================================================================
// Generated CAN Mailbox topology configuration
// Source model: intrepid.ucof
// Device: {device_name}
// Target implementation: {target_class} / {target_name}
// Mailbox config: {msg_box_name}
// Node address symbol: {node_symbol}
// ======================================================================

"""
    main += render_destination_filter_list(msg_box)
    main += render_outgoing_mailbox_slots(msg_box)
    main += render_sender_filter_list(msg_box)

    print_with_time(
        f"Writing IntrepidDebug mailbox topology into file: {output_path}"
    )
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(main)


init_log()
ucof_file_path_string = "intrepid.ucof"
ucof_platform = import_ucof_platform_from_file(ucof_file_path_string)
mailbox_entries = get_device_mailbox_configs(ucof_platform)

# Change this to "RDC_2" when you want the RDC-side generated file.
# Supported examples: "CPN", "RDC_2", "CAN_ADDR_CPN", "CAN_ADDR_RDC_2".
node_to_generate = "CPN"

selected_entry = get_mailbox_entry_by_node(mailbox_entries, node_to_generate)
selected_msg_box = selected_entry["msgBoxExtension"]
node_symbol = getattr(selected_msg_box, "nodeAddressSymbol", node_to_generate)
safe_node_name = str(node_symbol).replace("CAN_ADDR_", "").lower()
output_file_name = f"IntrepidDebugMailboxTopology_{safe_node_name}.hpp"
write_intrepid_debug_topology_into_file(selected_entry, output_file_name)