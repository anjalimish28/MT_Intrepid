import sys
from pathlib import Path

from general_utils import init_log, print_with_time, write_dics_to_csv, find_by_attr, find_by_class_name, select_from_list # type: ignore
from ucof_utils import import_ucof_platform_from_file, add_ports # type: ignore
sys.path.append(str(Path(__file__).parent / "PythonClasses"))

pin_map = {
    "Balance_Engine_0_Enable"    : "IO_PIN_MBS_EN",
    "Balance_Engine_0_Speed_PWM" : "PWM_PIN_MBS",
    "Balance_Engine_0_Direction" : "IO_PIN_MBS_DIR",
    "Gimbal_Engine_1_Enable"     : "IO_PIN_GIM_EN",
    "Gimbal_Engine_1_Speed_PWM"  : "PWM_PIN_GIM",
    "Gimbal_Engine_1_Direction"  : "IO_PIN_GIM_DIR",
    "Spindal_Engine_2_Enable"    : "IO_PIN_FLY_EN",
    "Spindal_Engine_2_Speed_PWM" : "PWM_PIN_FLY",
    "Spindal_Engine_2_Direction" : "IO_PIN_FLY_DIR"}

def get_hw_rdc(ucof_platform, device_id):
    hw_rdc = None
    impl_assignment = find_by_attr(ucof_platform, "sourceID", device_id, False, "DeviceToImplementationAssignment")
    if impl_assignment:
        implementation = find_by_attr(ucof_platform, "id", impl_assignment.targetID, False)
        impl_class = implementation.__class__.__name__
        if "stm32f446re" in impl_class:
            hw_rdc = implementation 
    return hw_rdc   

def get_timing(hw_rdc):
    timing = {}
    stm_timing = getattr(hw_rdc, "stmTimingConfig", None)
    if stm_timing is None:
        return timing
    for attr in ["rateDriverFrequencyHz", "rateGroupDivisor1", "rateGroupDivisor2",
                 "rateGroupDivisor3", "rateGroupDefaultOffset", "pwmResolutionBits"]:
        val = getattr(stm_timing, attr, None)
        if val is not None:
            timing[attr] = int(val)
    return timing

def get_rdc_config_header():
    header = """#ifndef RDC_CONFIG_HPP_
#define RDC_CONFIG_HPP_

#include <Fw/FPrimeBasicTypes.hpp>

namespace RdcConfig
{
"""
    return header

def get_rdc_config_footer():
    footer = """
} // namespace RdcConfig

#endif /* RDC_CONFIG_HPP_ */
"""
    return footer

def write_rdc_config_into_file(config_dic=None, timing_dic=None):
    header = get_rdc_config_header()
    footer = get_rdc_config_footer()
    main = ""

    rd_frq        = timing_dic.get("rateDriverFrequencyHz")  if timing_dic else None
    rg_div_1      = timing_dic.get("rateGroupDivisor1")       if timing_dic else None
    rg_div_2      = timing_dic.get("rateGroupDivisor2")       if timing_dic else None
    rg_div_3      = timing_dic.get("rateGroupDivisor3")       if timing_dic else None
    rg_def_offset = timing_dic.get("rateGroupDefaultOffset")  if timing_dic else None
    pwm_res       = timing_dic.get("pwmResolutionBits")       if timing_dic else None

    if rd_frq is not None:
        main += f"constexpr U8 RD_FRQ_HZ = {rd_frq};\n"
    if rg_div_1 is not None:
        main += f"constexpr U8 RG_DIV_1 = {rg_div_1};\n"
    if rg_div_2 is not None:
        main += f"constexpr U8 RG_DIV_2 = {rg_div_2};\n"
    if rg_div_3 is not None:
        main += f"constexpr U8 RG_DIV_3 = {rg_div_3};\n"
    if rg_def_offset is not None:
        main += f"constexpr U8 RG_DIV_DEF_OFFSET = {rg_def_offset};\n"
    if pwm_res is not None:
        main += f"constexpr U8 PWM_RES = {pwm_res};\n"

    if config_dic:
        for key, value in config_dic.items():
            main += f"constexpr U8 {key} = {value};\n"

    print_with_time(f"Writing rdcConfig into file.")
    with open("RdcConfig.hpp", "w", encoding="utf-8") as f:
        f.write(header)
        f.write(main)
        f.write(footer)

init_log()
ucof_file_path_string = "intrepid.ucof"
ucof_platform = import_ucof_platform_from_file(ucof_file_path_string)
device_list = ucof_platform.devices.device_list
for ucof_device in device_list:
    device_id = ucof_device.id
    print_with_time(f"Checking if device with id: {device_id} is RDC...")
    hw_rdc = get_hw_rdc(ucof_platform, device_id)
    if hw_rdc:
        print_with_time(f"... confirmed")
        rdc_config_dic = {}
        hw_rdc_port_list = hw_rdc.ports.port_list
        for port in hw_rdc_port_list:
            if port.name in pin_map.keys():
                print_with_time(f"Building rdcConfig dic entry for port with name: {port.name} and id: {port.id}")
                entry_name = pin_map[port.name]
                rdc_config_dic[entry_name] = port.pinName
                print_with_time(f"rdcConfig dic entry finished")
        timing_dic = get_timing(hw_rdc)
        write_rdc_config_into_file(rdc_config_dic, timing_dic)
    else:
        print_with_time(f"... NOT RDC")